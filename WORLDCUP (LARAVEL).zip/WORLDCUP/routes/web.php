<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

/*Route::get('/match', function () {
	DB::table('matches')->insert(array('id' => '1' , 'date' => '2018/06/20' ,'team1' => 'Brazil','team1_goal' => '4','team2' => 'Argentina','team2_goal' => '2','win_team' => 'Brazil'));
    return 'insert successful';
    DB::table('matches')->whereteam1('Brazil') ->delete();
});*/
Route::get('/', 'PagesController@home1');
Route::get('/newhome', 'PagesController@home2');
Route::get('/statistics', 'PagesController@sta');
Route::get('/Football/teams', 'TeamsController@index');
Route::get('/Football/teams1', 'TeamsController@search');
Route::get('/Football/teams2', 'TeamsController@search1');
Route::get('/Football/teams3', 'TeamsController@search2');
//Route::get('/awards', 'Pagescontroller@awards');
Route::get('/news', 'PagesController@news');
Route::get('/news1', 'PagesController@news1');
Route::get('/news2', 'PagesController@news2');
Route::get('/news3', 'PagesController@news3');
Route::get('/news4', 'PagesController@news4');
//Route::get('/teams','TeamsController@teams');
Route::get('/match2', 'PagesController@match');
Route::get('/match2', 'MatchesController@index');
Route::get('/match', 'MatchesController@search');
Route::get('/match', 'MatchesController@search1');

Route::get('/players', 'PlayersController@search');
Route::get('/players_croatia', 'PlayersController@search1');
Route::get('/players_england', 'PlayersController@search2');
Route::get('/players_belgium', 'PlayersController@search3');
Route::get('/players_neymar', 'PlayersController@search4');
Route::get('/players_nan', 'PlayersController@search5');
Route::get('/players_harry', 'PlayersController@search6');
Route::get('/players_thibaut', 'PlayersController@search7');

Route::get('/groups', 'GroupsController@index');
Route::get('/groups1', 'GroupsController@search');

Route::resource('/Award/insert', 'AwardsController@create');
Route::post('/Award', 'AwardsController@store');
Route::get('/Award/display', 'AwardsController@index');
Route::get('/Award/update/{id}','AwardsController@update');
Route::post('/Award/edit/{id}','AwardsController@edit');
Route::get('/Award/read/{id}','AwardsController@read');
Route::get('/Award/delete/{id}','AwardsController@delete');

Route::get('/login', 'PagesController@login');
Route::get('/register', 'PagesController@register');
Route::post('/register_action','CustomAuthController@store');
Route::post('/login_check','CustomAuthController@login');
Route::get('/logout', function () {
	Auth::logout();

	return Redirect::to('');
})->middleware("auth");