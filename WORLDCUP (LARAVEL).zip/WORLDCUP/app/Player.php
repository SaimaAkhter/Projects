<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Player;
use App\Team;

class Player extends Model
{
    public function user()
{
 return $this->belongsTo('App\User');
}
public function getTitle()
{
 return $this->title;
}
public function teams(){
	return $this->belongsTo('Team', 'Country', 'id');
}

}
