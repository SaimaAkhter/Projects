<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function home1()
	{
		return view('home');
	}
	 public function news()
	{
		return view('news');
	}
	
	public function match()
	{
		return view('match2');
	}
	public function login()
	{
		return view('login');
	}
	public function register()
	{
		return view('register');
	}
    
public function home2()
	{
		return view('newhome');
	}
   public function news1()
	{
		return view('news1');
	}

	public function news2()
	{
		return view('news2');
	}
	public function news3()
	{
		return view('news3');
	}
	public function news4()
	{
		return view('news4');
	}
	public function sta()
	{
		return view('statistics');
	}


}
