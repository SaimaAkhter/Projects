<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// Illuminate\Support\Facades\Request ;
use App\match;

//use Request;

class MatchesController extends Controller
{
    public function search()
    {
        $searchkey = \Request::get('title');
        $match =  match::where('team1', 'like', '%' .$searchkey. '%')->orderBy('id')->paginate(5);
        return view('match', ['a' => $match]);
    }
    public function search1()
    {
        $searchkey = \Request::get('win');
        $match =  match::where('win_team', 'like', '%' .$searchkey. '%')->orderBy('id')->paginate(5);
        return view('match', ['a' => $match]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $matches = match::all();
        return view('match2',['a' => $matches] );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}


