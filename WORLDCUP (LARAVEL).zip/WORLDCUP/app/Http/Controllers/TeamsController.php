<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Football;
use App\Team;

class TeamsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teams = Team::all();
        return view('Football.teams', compact('teams'));
    }
    public function search(Request $request)
    {
        $goals = DB::table('teams')->max('Goals_Scored');
        $match =  Team::where('Goals_Scored', 'like', '%' .$goals. '%')->orderBy('id')->paginate(5);
        return view('Football.teams1', ['a' => $match]);
    }

     public function search1(Request $request)
    {
        $goals = DB::table('teams')->max('Matches_Played');
        $match =  Team::where('Matches_Played', 'like', '%' .$goals. '%')->orderBy('id')->paginate(5);
        return view('Football.teams2', ['a' => $match]);
    }

    public function search2(Request $request)
    {
        $goals = DB::table('teams')->min('Minutes_Played');
        $match =  Team::where('Minutes_Played', 'like', '%' .$goals. '%')->orderBy('id')->paginate(5);
        return view('Football.teams3', ['a' => $match]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Football.teams');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
