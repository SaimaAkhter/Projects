<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Award;
use App\award\insert;
use App\award\display;
use App\award\update;


class AwardsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $awards =  award::all();
        return view('Award.display', compact('awards'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Award.insert');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'player'  => 'required',
            'country' =>  'required'
        ]);
        $award = new Award(array(
            'Player'     =>    $request-> get('player'),
            'Country'    =>     $request-> get('country'),
            'Award_Name' =>     $request-> get('award_name'),
            'Age'        =>     $request-> get('age'),
            'Int_Goals'  =>     $request-> get('int_goals')
        ));
        $award ->save() ;
        return redirect('/Award/display')->with('success','Data Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //return $id;
        $this->validate($request, [
            'player'  => 'required',
            'country' =>  'required'
        ]);
        $data = array(
             'player'    =>     $request-> get('player'),
            'country'    =>     $request-> get('country'),
            'award_name' =>     $request-> get('award_name'),
            'age'        =>     $request-> get('age'),
            'int_goals'  =>     $request-> get('int_goals')
        );
        award::where('id',$id)
        -> update($data);
        return redirect('/Award/display')->with('success','Data Updated');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update( /*Request $request,*/ $id)
    {
        $awards =  award::find($id);
        return view('Award.update',['awards' => $awards], compact('awards'));
    }
    public function read( /*Request $request,*/ $id)
    {
        $awards =  award::find($id);
        return view('Award.read',['awards' => $awards], compact('awards'));
    }
    public function delete( /*Request $request,*/ $id)
    {
         award::where('id',$id)
        -> delete();
        return redirect('/Award/display')->with('success','Data Deleted');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
