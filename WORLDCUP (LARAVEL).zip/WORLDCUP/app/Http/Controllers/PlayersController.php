<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Player ;
use App\Team;
use DB;
class PlayersController extends Controller
{
     public function search()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('teams.Country', 'Brazil')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players', ['a' => $player],compact('player'));
    }

    public function search1()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('teams.Country', 'Croatia')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_croatia', ['a' => $player],compact('player'));
    }
    public function search2()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('teams.Country', 'England')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_england', ['a' => $player],compact('player'));
    }
    public function search3()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('teams.Country', 'Belgium')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_belgium', ['a' => $player],compact('player'));
    }
    public function search4()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('players.Player','Neymar')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_neymar', ['a' => $player],compact('player'));
    }

    
public function search5()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('players.Player','Nan Perisic')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_nan', ['a' => $player],compact('player'));
    }
    public function search6()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('players.Player','Harry Kane')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_harry', ['a' => $player],compact('player'));
    }
     public function search7()
    {
     $player =DB::table('players')
            ->join('teams', 'players.Player', '=', 'teams.Player')
            ->where('players.Player','Thibaut Cortois')
            ->select('players.Player', 'players.Age','players.Height','players.Int_goals','players.Int_caps', 'teams.Minutes_Played','teams.Goals_Scored','teams.Matches_Played','teams.Yellow_Cards')
            ->get();
            return view('/players_thibaut', ['a' => $player],compact('player'));
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       /* $play = DB::table('')->select('name', 'email')->get();
        return view('match2',['a' => $matches] );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    //public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function destroy($id)
    {
        //
    }
}
}
