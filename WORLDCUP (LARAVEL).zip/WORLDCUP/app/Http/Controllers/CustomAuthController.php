<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Input;
use Validator;
use Redirect;
use App\Register;
use Auth;

class CustomAuthController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    //public function index()
    /*{
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    //public function create()
    /*{
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $data=Input::except(array('_token'));
    
    $rule=array (
            'username'     =>   'required',
            'email'    => 'required|email',  
            'pwd' => 'required|min:6',
            'cpwd' => 'required|same:pwd' 
        );
    $message =array(
        'cpwd.required' => 'the confirm password is required',
        'cpwd.min'  => 'the confirm password must be minimum 6 characters',
        'cpwd.same' => 'the confirm password must be same with password',
    );

    $validator=Validator::make($data,$rule,$message);

    if($validator->fails()){
       return Redirect::to('/register')->withErrors($validator);
    }
        else{
            Register::formstore(Input::except(array('_token','cpwd')));
        }

        return Redirect::to('/register')->with('success','Successfully Registered');
    }
    

    public function login(){
        $data=Input::except(array('_token'));
    
    $rule=array (
            'email'    => 'required|email',  
            'pwd' => 'required',
        );

    $validator=Validator::make($data,$rule);

    if($validator->fails()){
       return Redirect::to('/login')->withErrors($validator);
    }
        else{

             //$data=Input::except(array('_token'));
             //var_dump($data);

            $userdata = array(
                'email' => Input::get('email'),
                 'password' => Input::get('pwd')
            );
             if (Auth::attempt($userdata)) {
                return Redirect::to('/');
                //echo "yes";
             }
             else{
                return Redirect::to('/login');
                //echo "no";
             }
    }
}
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function show($id)
    /*{
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function edit($id)
    /*{
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function update(Request $request, $id)
    /*{
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //public function destroy($id)
    /*{
        //
    }
}
