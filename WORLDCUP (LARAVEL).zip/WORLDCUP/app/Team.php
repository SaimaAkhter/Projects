<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Player;
use App\Team;

class Team extends Model
{
    public function user()
{
 return $this->belongsTo('App\Football');
}
public function getTitle()
{
 return $this->title;
}

public function players(){
	return $this->hasMany('Player', 'Country', 'id');
}

}
