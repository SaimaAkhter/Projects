<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Input;
use Hash;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Register extends Authenticatable
{

    protected $table = "register_users" ;

    public static function formstore(){
    	//$cho "here model is";
    	$username = Input::get('username');
    	$email = Input::get('email');
    	$pwd = Hash::make(Input::get('pwd'));

    	$users =new Register();

    	$users ->name=$username;
    	$users ->email=$email;
    	$users ->password=$pwd;

    	$users -> save() ;

    }
}
