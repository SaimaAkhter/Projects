<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class award extends Model
{
	protected $fillable =['Player','Country','Award_Name','Age','Int_Goals'];
    public function user()
{
 return $this->belongsTo('App\User');
}
public function getTitle()
{
 return $this->title;
}
}
