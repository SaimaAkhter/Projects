<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('players', function (Blueprint $table) {
 $table->increments('id');
 $table->string('Player', 255);
 $table->string('Country', 255);
 $table->integer('Age');
 $table->string('Height',255)->nullable();
  $table->integer('Int_goals')->nullable();
 $table->integer('Int_caps')->nullable();
$table->timestamps();
 });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('players');
    }
}
