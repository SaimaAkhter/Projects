<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAwardsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Awards', function (Blueprint $table) {
 $table->increments('id');
 $table->string('Player', 255);
 $table->string('Country', 255);
 $table->string('Award_Name');
 $table->integer('Age')->nullable();
  $table->integer('Int_Goals')->nullable();
$table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Awards');
    }
}
