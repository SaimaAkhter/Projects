	<?php $__env->startSection('title', 'Display'); ?></title>
	<style type="text/css">
		.right{
front-weight:bold;
color:#FFFFFF;
background-color:#98bf21;
width:120px;
text-align:center;
padding:4px;
text-transform:uppercase;
text-decoration:none;
}
	</style>

	<?php $__env->startSection('content'); ?>
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">AWARDS DETAILS</h3>
			<?php if($message = Session::get('success')): ?>
			<div class="alert alert-success">
					<p><?php echo e($message); ?></p>
			</div>
			<?php endif; ?>
			<div class="right" align="right">
				<a href="/Award/insert" class="btn-btn-primary">ADD</a>
			</div>
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>AWARD NAME</th>
					<th>Age </th>
					<th>International Goals</th>
					<th>Action</th>
				</tr>
				<?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($row['id']); ?></td>
					<td><?php echo e($row['Player']); ?></td>
					<td><?php echo e($row['Country']); ?></td>
					<td><?php echo e($row['Award_Name']); ?></td>
					<td><?php echo e($row['Age']); ?></td>
					<td><?php echo e($row['Int_Goals']); ?></td>
					<td>
						<a href="/Award/read/<?php echo e($row['id']); ?>" class="btn-btn-primary">READ</a>
						<a href="/Award/update/<?php echo e($row['id']); ?>" class="btn-btn-primary">UPDATE</a>
						<a href="/Award/delete/<?php echo e($row['id']); ?>" class="btn-btn-primary">DELETE</a>
					</td>

				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</table>
		
		</div>
				
		</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>