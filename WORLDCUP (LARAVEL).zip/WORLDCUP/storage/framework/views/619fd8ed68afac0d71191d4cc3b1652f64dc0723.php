	<?php $__env->startSection('title', 'Groups'); ?></title>
	<?php $__env->startSection('content'); ?>
	<form class="navbar-form" role="search" method="GET" action="<?php echo e(url("/groups1")); ?>">
        <div class="input-group">
            <label>   Search by Group Name
            <div class="input-group-btn" >
                <input type="text" class="form-control" placeholder="Search" name="title">
            
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button></label>
            </div>
        </div>
    </form>

<table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>GROUP NAME</th>
                    <th>COUNTRY</th>
                    
                </tr>
        
<?php if(count($a)>0): ?>
<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($groups->id); ?></td>
<td><?php echo e($groups->Group_Name); ?></td>
<td><?php echo e($groups->Country); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<?php endif; ?>


        <?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>