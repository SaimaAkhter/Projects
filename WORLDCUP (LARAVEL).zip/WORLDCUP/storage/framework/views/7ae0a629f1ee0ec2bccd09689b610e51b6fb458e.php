	<?php $__env->startSection('title', 'Groups1'); ?></title>
	<?php $__env->startSection('content'); ?>

<table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>GROUP NAME</th>
                    <th>COUNTRY</th>
                    
                </tr>
        
<?php if(count($a)>0): ?>
<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($groups->id); ?></td>
<td><?php echo e($groups->Group_Name); ?></td>
<td><?php echo e($groups->Country); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<?php endif; ?>


        <?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>