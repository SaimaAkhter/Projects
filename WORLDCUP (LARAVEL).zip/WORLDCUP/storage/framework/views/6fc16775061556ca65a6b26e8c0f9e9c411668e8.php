	<?php $__env->startSection('title', 'Match'); ?></title>
	<?php $__env->startSection('content'); ?>
	
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">MATCH DETAILS</h3>
			
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>DATE</th>
					<th>TEAM1</th>
					<th>TEAM1 SCORE</th>
					<th>TEAM2</th>
					<th>TEAM2 SCORE</th>
					<th>WINS</th>
					<th>STADIUM</th>
				</tr>
        
<?php if(count($a)>0): ?>
<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matches): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($matches->id); ?></td>
<td><?php echo e($matches->date); ?></td>
<td><?php echo e($matches->team1); ?></td>
<td><?php echo e($matches->team1_goal); ?></td>
<td><?php echo e($matches->team2); ?></td>
<td><?php echo e($matches->team2_goal); ?></td>
<td><?php echo e($matches->win_team); ?></td>
<td><?php echo e($matches->stadium); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>


	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>