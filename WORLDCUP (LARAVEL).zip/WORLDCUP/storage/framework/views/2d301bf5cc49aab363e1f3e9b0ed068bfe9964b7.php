
<html>
<head>
<title> <?php echo $__env->yieldContent('title'); ?> </title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
<!-- Material Design fonts -->
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700">
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/icon?family=Material+Icons">
<!-- Bootstrap -->
<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Bootstrap Material Design -->
<link rel="stylesheet" type="text/css" href="/css/bootstrap-material-design.css">
<link rel="stylesheet" type="text/css" href="/css/ripples.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	body,
    html {
        height: 80%;

        margin: 0;
        font-size: 16px;
        font-family: "Lato", sans-serif;
        font-weight: 400;
        line-height: 1.8em;

    }

    .pimg0 {
        background-image: url("/images/coaches.jpg");
        min-height: 100%;
    }

    .pimg1 {
        background-image: url("/images/players.jpg");
        min-height: 100%;
    }

    .pimg2 {
        background-image: url("/images/mbappe.jpg");
        min-height: 100%;
    }

    .pimg3 {
        background-image: url("/images/brazil.jpg");
        min-height: 100%;
    }

    .pimg0,
    .pimg1,
    .pimg2,
    .pimg3 {
        position: relative;
        opacity: 0.70;
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    .section {
        text-align: center;
        padding: 50px;
    }

    .section-light {
        background-color: #f4f4f4;
        color: #666;
    }

    .section-dark {
        background-color: #282e34;
        color: #ddd;
    }
    .ptext {
        position: absolute;
        top: 50%;
        width: 100%;
        text-align: center;
        color: #000;
        font-size: 27px;
        letter-spacing: 8px;
        text-transform: uppercase;
    }

    .ptext,
    .border {
        color: #f7f7f7;
        padding: 20px;
    }


    .navbar {
        margin-bottom: 0;
        background-color: #2d2d30;
        border: 0;
        font-size: 11px;
        letter-spacing: 4px;
        opacity: 0.9;
    }

    .navbar li a,
    .navbar .navbar-brand {
        color: #d5d5d5 ;
    }

    .navbar-nav li a:hover {
        color: #939496 ;
    }
    footer {
        background-color: #2d2d30;
        color: #f5f5f5;
        padding: 20px;
        font-family: Arial;
        letter-spacing: 3px;

        margin: 0px;
    }

    .bg {
        background-color: #282e34;
        height: 100px;
        width: 1350px;
        padding: 10px;
        background-size: cover;
        font-size: 17px;
        letter-spacing: 2px;
        text-transform: uppercase;
        margin-top: -30px;
        text-align: center;
        


    }
    .btn {
        background-color: #6d756a;

        border: none;
        color: white;
        padding: 16px 32px;
        text-align: center;
        font-size: 16px;
        margin: 15px 5px;
        opacity: 1;
        transition: 0.3s;
    }
   @media(max-width:568px) {
    .pimg1,
    .pimg2,
    .pimg3,
    .bg {
        background-attachment: scroll;
    }
    .logo{
    	width:20px;
    	height: 2px;
    }
}
</style>
</head>

<body>
<?php echo $__env->make('shared.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="/js/ripples.min.js"></script>
<script src="/js/material.min.js"></script>
<script>
$(document).ready(function() {
	// This command is used to initialize some elements and make them work properly
	$.material.init();
});
</script>

<div class="jumbotron jumbotron-fluid ag"style="color:green;">
        <div class="container"style="color:green;">
            <h2 style="color:green;">15 Jul 2018 - Final - Luzhniki Stadium Moscow</h2>
            <p style="color:green;">France <img class="logo" src="images\france.png">  4-2   Croatia <img class="logo" src="images\croatia.png"> </p>

            <br>
            <br>
            <br>
            <div class="container" style="color:green;">

                <form>
                    <div class="form-group row">
                        
                        <span class="switchButton" id="switchButton"></span>           
                    
                   </div>
                </form>
            </div>

        </div>
    </div>
    <div class="contianer-fluid"></div>

    <div class="container bg">
        <p style="color:#fff;">RUSSIA 2018: AWARDS
Find out who collected the various individual and collective awards at the 2018 FIFA World Cup Russia.</p>

    </div>
    <div class="pimg0">
        <div class="ptext">
            <span class="border">
                
            </span>

        </div>
    </div>
    <section class="section section section-dark">
        <p>Cheer for your team in 2018 worldcup 



        </p>
    </section>



    <div class="pimg1">
        <div class="ptext">
            <span class="border">
               
            </span>

        </div>
    </div>
    <section class="section section section-dark">
        <p>Top Scorers</p>
        <p>HARRY KANE      ANTOINE GRIEZMANN     ROMELU LUKAKU<br></p>
        
    </section>

    <div class="pimg2">
        <div class="ptext">
            <span class="border ">
                 
            </span>

        </div>
    </div>
    <section class="section section section-dark">
        <p>A 360° photo was taken at both the Opening and Closing matches at Russia 2018. Were you there? Scroll, zoom, tag and share!</p>
    </section>
    <div class="pimg3">
        <div class="ptext">
            <span class="border ">
                
            </span>

        </div>
    </div>
    <section class="section section section-dark">
        <p>We use "cookies" to collect information. </p>
    </section>
    <div class="container-fluid eg">
        <div class="row">
            <div class="col-sm-4">
                <h4 style="color:#404043;padding:20px;margin-top:25px;"><strong></strong></h4>
                <ul style="list-style-type:none;margin-left:-18px;color:#979799;font-size:15px;">
                    

                </ul>
            </div>
            <div class="col-sm-4">
                <h4 style="color:#404043;padding:20px;margin-top:25px;"><strong></strong></h4>
                <ul style="list-style-type:none;margin-left:-18px;color:#979799;font-size:15px;">
                    


                </div>

            </div>
        </div>



        <!--footer-->
        <footer>
            <p style="font-size:20px;">Copyright Â© 2018 WORLDCUP.COM All Rights Reserved</p>
        </footer>
    </body>

    </html>



</body>
</html>