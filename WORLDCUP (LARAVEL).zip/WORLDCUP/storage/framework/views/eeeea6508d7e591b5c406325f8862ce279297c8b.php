	<?php $__env->startSection('title', 'news'); ?></title>
    <style type="text/css">
    	/*.container{
    		
    		height: 200px;
    	}*/
    	img{
    		width:500px;
    	height: 2px;
    	
    }
    </style>
	<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 100px;" >
	<p>
    <li>Russia jumped 21 positions in the FIFA/Coca-Cola World Ranking</li>
<li>One of the main reasons behind their World Cup success was Artem Dzyuba</li>
<li>The imposing striker is now a fan idol in Russia</li>
<span>
Extra time in one of the most enthralling encounters of the 2018 FIFA World Cup™ had drawn to a close with the score at 2-2. Penalties were needed to decide the victor between Russia and Croatia. The Sbornaya players gathered into a huddle around one man, who was seen vigorously rousing his team-mates for the final push to determine which team would advance into the last four.

Despite the deafening din at the Fisht Stadium, television cameras caught every word of Artem Dzyuba’s speech. The towering striker had already been substituted and thus was unable to volunteer himself for the penalty shootout. But it nevertheless fell to him to provide the motivation. “Lads, I’m proud of you! I love you! " he said. "Just enjoy the moment right now. He [Croatia goalkeeper Danijel Subasic] moves early, don’t rush it! If you don’t feel confident, strike down the centre! Let’s go!”

Dzyuba’s passionate words ultimately did not bring victory for Russia, of course, as Croatia took the last spot in the semi-final. But after the game, Artem endeared himself to the nation again as he broke down in tears live on television. “I’m proud of my team-mates and I love them like family," he said. "We’ve become one big family. We wanted to prove to the entire country that football here is alive, so people would be proud of us. Thanks to everyone. We’re heartbroken.”

</span></p>
</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>