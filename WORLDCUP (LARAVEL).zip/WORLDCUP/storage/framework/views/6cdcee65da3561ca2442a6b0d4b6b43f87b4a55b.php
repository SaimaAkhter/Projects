	<?php $__env->startSection('title', 'READ'); ?></title>
	<style type="text/css">
		.right{
front-weight:bold;
color:#FFFFFF;
background-color:#98bf21;
width:120px;
text-align:center;
padding:4px;
text-transform:uppercase;
text-decoration:none;
}
	</style>

	<?php $__env->startSection('content'); ?>
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">AWARDS DETAILS</h3>
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>AWARD NAME</th>
					<th>Age </th>
					<th>International Goals</th>
				</tr>
				<tr>
					<td><?php echo e($awards['id']); ?></td>
					<td><?php echo e($awards['Player']); ?></td>
					<td><?php echo e($awards['Country']); ?></td>
					<td><?php echo e($awards['Award_Name']); ?></td>
					<td><?php echo e($awards['Age']); ?></td>
					<td><?php echo e($awards['Int_Goals']); ?></td>
					</tr>
			</table>
		
		</div>
				
		</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>