	<?php $__env->startSection('title', 'statistics'); ?></title>
    <style type="text/css">
    .logo{
        width:500px;
        height: 1px;
        padding: 0;
    }
    h2{
        left: 3px;
        top: 10px;
    }
    ul{
        padding: 0;
    }
    
    </style>
	<?php $__env->startSection('content'); ?>
     
    <div class="jumbotron jumbotron-fluid ag "style="color:green;">
        <div class="container"style="color:green;">
        <h2 style="color:green;">TEAMS</h2>
           <div class="col-md-3">
            <p style="color:green;">TOP GOALS</p>
            <img class="logo" src="images\brazil.png" >
            <a href="/players" class="btn-btn-primary">
                <label><br><br><br>BRAZIL</label></a>
        </div>
        <div class="col-md-3">
            <p style="color:green;">BEST ATTACKING</p>
            <img class="logo" src="images\croatia.png">
            <a href="/players_croatia" class="btn-btn-primary">
                <label><br><br><br>CROATIA</label></a>
        </div>
        <div class="col-md-3">
            <p style="color:green;">BEST PASSING</p>
            <img class="logo" src="images\england.png">
             <a href="/players_england" class="btn-btn-primary">
                <label><br><br><br>ENGLAND</label></a>
        </div>
        <div class="col-md-3">
            <p style="color:green;">BEST DEFENDING</p>
            <img class="logo" src="images\belgium.png">
            <a href="/players_belgium" class="btn-btn-primary">
                <label><br><br><br>Belgium</label></a>
        </div>
        </div>
    </div>

    <div class="jumbotron jumbotron-fluid ag "style="color:green;">
        <div class="container"style="color:green;">
        <h2 style="color:green;">PLAYERS</h2>
           <div class="col-md-3">
            <p style="color:green;"><br>MOST ATTEMPTS</p>
            <img class="logo" src="images\neymar.jpg" height="-5px">
            <a href="/players_neymar" class="btn-btn-primary"><label name="Neymar">NEYMAR</label></a>
            <ul>BRAZIL</ul>
        </div>
        <div class="col-md-3">
            <p style="color:green;">MOST DISTANCE COVERED</p>
            <img class="logo" src="images\nan.jpg">
            <a href="/players_nan" class="btn-btn-primary"><label id="Nan Perisic" value="Nan Perisic">NAN PERISIC</label></a>
            <ul>CROATIA</ul>
        </div>
        <div class="col-md-3">
            <p style="color:green;">MOST PASSES COMPLETED</p>
            <img class="logo" src="images\ramos.png">
            <a href="/players_harry" class="btn-btn-primary"><label>HARRY KANE</label></a>
            <ul>ENGLAND</ul>
        </div>
        <div class="col-md-3">
            <p style="color:green;"><br>MOST SAVES</p>
            <img class="logo" src="images\thibaout.png">
            <a href="/players_thibaut" class="btn-btn-primary"><label>THIBAUT COURTOIS</label></a>
            <ul>BELGIUM</ul>
        </div>
        </div>

    </div>
     
    <?php $__env->stopSection(); ?>



   
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>