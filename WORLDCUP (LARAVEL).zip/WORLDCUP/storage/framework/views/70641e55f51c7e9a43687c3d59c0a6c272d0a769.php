<!DOCTYPE html>
<html>
<head>
<title> <?php echo $__env->yieldContent('title'); ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Material Design fonts -->
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700">
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/icon?family=Material+Icons">
<!-- Bootstrap -->
<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Bootstrap Material Design -->
<link rel="stylesheet" type="text/css" href="/css/bootstrap-material-design.css">
<link rel="stylesheet" type="text/css" href="/css/ripples.min.css">
<style type="text/css">
	.header {
	text-align: center;
	position: relative;
    border: 3px solid green;
    background-color: #4CAF50;
    color: white;
    width: 100%;
  height: 150px;
  display: flex;
  justify-content: left ;
  align-items: center;
  font-size: 20px;

}
.navbar{
	display: block;
    padding: 8px;
    list-style-type: none;
    background-color: #333;
}
a:link,a:visited{
front-weight:bold;
color:#FFFFFF;
background-color:#98bf21;
width:120px;
text-align:center;
padding:4px;
text-transform:uppercase;
text-decoration:none;
}

a:hover,a:active{
background-color:#7A991A;
}
h2 {
    color: white;
}
h5{
	color: blue;
	font-size:16px;
}
.lines{
	border-bottom: 3px solid

}
.logo{
  height: 160px ;
  width:120px;
  padding: 10px;
}
p{
  font-size: 20px;
}

</style>

</head>
<body>

<script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="/js/ripples.min.js"></script>
<script src="/js/material.min.js"></script>
<script>
$(document).ready(function() {
	// This command is used to initialize some elements and make them work properly
	$.material.init();
});
</script>

<!-- Header -->
<div class="header">
  <img class="logo" src="\images\logo.png">
  <h2>2018 FIFA WORLD CUP RUSSIA<br>
  <p>14 JUNE-<b>15 JULY</b></p></h2>
</div>

<!-- Navigation Bar -->
<div class="navbar">
  <?php if(Auth::user()): ?>
  <a href="/Football/teams">Teams</a>
  <a href="/news">NEWS</a>
  <a href="/match2">MATCHES</a>
  <a href="/Award/display">AWARDS</a>
  <a href="/statistics">STATISTICS</a>
  <a href="/groups">GROUPS</a>

  <ul class="nav navbar-nav navbar-right">
    <a href="/logout">
      <span style="color: white"> <?php echo e(ucwords(Auth::user()->name)); ?></span> <span class="glyphicon glyphicon-log-in"></span>
    Logout</a></ul>

    <?php else: ?>
      <a href="/register"><span class="glyphicon glyphicon-user"></span> Sign Up</a>
      <a href="/login"><span class="glyphicon glyphicon-log-in"></span> Login</a>
      
    </ul>
    <?php endif; ?>
  
</div>
</body>
</html>
