	<?php $__env->startSection('title', 'Update'); ?></title>
	<style type="text/css">
		.form-group{
			padding: 10px;
			 width: 100%;
    padding-bottom: 15px;
		}
		.form-control{
			width: 50%;
			background: transparent;
			border: 0;
	border : 1px solid #ffecb3;
	width: 100%;
	padding: 8px 10px;
	font-size: 1em;
	color: #ffecb3;
	border-radius: 3px;
	position: relative;
		}
		.row{
			width: 100%;
	max-width: 500px;
	height: auto;
	padding: 40px 20px;
	border-radius: 5px;
		}

	</style>
	<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-12" >
			<h3 align="center">Awards</h3>
			<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(\Session::has('success')): ?>
			<div class="alert alert-success">
					<p><?php echo e(\Session::get('success')); ?></p>
			</div>
			<?php endif; ?>

			<form method="post" action="<?php echo e(url('Award/edit', array($awards -> id))); ?>">
				<div class="form-group">
					<?php echo e(csrf_field()); ?>

					<label>Player</label>
					<input type="text" name="player" class="form-control" placeholder="value" value="<?php echo $awards -> Player;?>">
				</div>
				<div class="form-group">
					<label>Country</label>
					<input type="text" name="country" class="form-control" placeholder="value" value="<?php echo $awards -> Country;?>">
				</div>
				<div class="form-group">
					<label>Award Name</label>
					<input type="text" name="award_name" class="form-control" placeholder="value" value="<?php echo $awards -> Award_Name;?>">
				</div>
				<div class="form-group">
					<label>Age</label>
					<input type="text" name="age" class="form-control" placeholder="value" value="<?php echo $awards -> Age;?>">
				</div>
				<div class="form-group">
					<label>International Goals</label>
					<input type="text" name="int_goals" class="form-control" placeholder="value" value="<?php echo $awards -> Int_Goals;?>">
				</div>
				<div class="form-group">
					<button type="submit" name="submit" class="btn-btn-primary" style="color: green;">UPDATE</button>
					<a href="/Award/display" class="btn-btn-primary">BACK</a>
				</div>
			</form>
		</div>
	</div>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>