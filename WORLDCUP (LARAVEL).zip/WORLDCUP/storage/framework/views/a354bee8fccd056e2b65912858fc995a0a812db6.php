	<?php $__env->startSection('title', 'news'); ?></title>
    <style type="text/css">
    	/*.container{
    		
    		height: 200px;
    	}*/
    	img{
    		width:500px;
    	height: 2px;
    	
    }
    </style>
	<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 100px;" >
	<p>
    <span>1998 had always been seen as French football’s annus mirabilis, a year that reached its peak with the national team’s victory at their home FIFA World Cup™. Now, 20 years down the line, a second star can be sewn on to those iconic blue shirts following the triumphant performance of Didier Deschamps’ men at Russia 2018.

This begs a question: what if 2018 was to go so far as to surpass 1998 in the hearts of French football fans? Indeed, quite aside from their coronation in Moscow, a series of recent events have combined to make 2018 a golden period for the French Football Federation.

We take a closer look at the unique run of success that has seen France re-emerge at the centre of the footballing universe.

1 - A second star in the blue sky
On 15 July 2018, at around 21.00 local time, the heavens opened above Moscow. Soon the pitch at the Luzhniki Stadium was being pounded by a torrential downpour of rain. However, an even greater force of nature was destined to rise above the deluge that evening, with the sound of the rain drowned out by the cries of joy and emotion emanating from the French players as Hugo Lloris raised the World Cup aloft following their resounding 4-2 victory over Croatia. And so the likes of Raphael Varane, Antoine Griezmann, Paul Pogba, Ngole Kante and Olivier Giroud wrote their names into the history books alongside Zinedine Zidane, Fabien Barthez, Laurent Blanc and, above all, their coach Didier Deschamps, who had enjoyed the same honour as Lloris back in 1998.

Kylian Mbappe was not yet born when Deschamps became the first Frenchman to lift the historic trophy. Nonetheless, he was determined to leave his mark on this year’s tournament, scoring a goal in the final and winning the FIFA Young Player award. “We’ve won and it’s only the beginning, we’re going to savour this for four years!” enthused his team-mate Benjamin Pavard, scorer of the Goal of the Tournament.
2 - Hosting the FIFA U-20 Women's World Cup 2018
Barely had the celebrations in tribute to that historic title died down than another World Cup was kicking off. But where? In France, of course! The FIFA U-20 Women's World Cup is currently being held in Brittany. The four host cities - Concarneau, Dinan-Lehon, Saint-Malo and Vannes - have pulled out all the stops to provide a suitably warm welcome for the 16 teams and their supporters. Les Bleuettes advanced to the competition's semi-finals.
3 - Qualification for the FIFA U-20 World Cup 2019
Not to be left out, the men’s U-19 team also got in on the action by reaching the semi-finals of the UEFA European U-19 Championship in Finland. They may have fallen short against Italy but, thanks to their strong showing, Les Bleuets - managed by Bernard Diomede, yet another world champion back in 1998 - have secured their place at the FIFA U-20 World Cup Poland 2019. “What is satisfying is to have reached the semi-finals and to have qualified for the World Cup, whereas big countries such as Spain, Germany, England, Belgium and the Netherlands won’t be there,” admitted Diomede.

4 - The countdown to France 2019: one year to go
Whatever happens, 2019 promises to be another memorable 12 months for French football, with the country set to host the FIFA Women's World Cup. With a year to go, the most prestigious event in women’s football is already starting to take shape. In recent months, FIFA and the Local Organising Committee have unveiled the Official Mascot - a young chicken named Ettie, the daughter of France 1998 mascot Footix -, launched the Volunteer Programme, and announced the match schedule for the finals.
</span></p>
</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>