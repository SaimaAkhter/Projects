	<?php $__env->startSection('title', 'login'); ?></title>
	<?php $__env->startSection('content'); ?>

    <div class="container">
  <h2>Vertical (basic) form</h2>
  <form action="/login_check" method="post">

    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
       <?php if($errors->has('email')): ?> <p><?php echo e($errors -> first('email')); ?></p> <?php endif; ?>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
       <?php if($errors->has('pwd')): ?> <p><?php echo e($errors -> first('pwd')); ?></p> <?php endif; ?>
    </div>
    <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>