	<?php $__env->startSection('title', 'Player'); ?></title>
	<?php $__env->startSection('content'); ?>


	<table class="table table-bordered">
				<tr>
					<th>Player</th>
					<th>Age</th>
					<th>Height</th>
					<th>International Goals</th>
					<th>International Caps</th>
					<th>Minutes Played</th>
					<th>Goals Scored</th>
					<th>Matches Played</th>
					<th>Yellow Cards</th>
				</tr>
        
<?php if(count($a)>0): ?>
<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($player->Player); ?></td>
<td><?php echo e($player->Age); ?></td>
<td><?php echo e($player->Height); ?></td>
<td><?php echo e($player->Int_goals); ?></td>
<td><?php echo e($player->Int_caps); ?></td>
<td><?php echo e($player->Minutes_Played); ?></td>
<td><?php echo e($player->Goals_Scored); ?></td>
<td><?php echo e($player->Matches_Played); ?></td>
<td><?php echo e($player->Yellow_Cards); ?></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>