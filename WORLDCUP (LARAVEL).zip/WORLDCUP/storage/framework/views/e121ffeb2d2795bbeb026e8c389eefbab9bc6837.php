	<?php $__env->startSection('title', 'login'); ?></title>
	<?php $__env->startSection('content'); ?>

    <div class="container">
      <?php if(Session::has('success')): ?>
      <div class="row">
      <div class="col-md-12" >
      <div class="alert alert-success">
          <p><?php echo e(Session::get('success')); ?></p>
      </div>
    </div>
  </div>
      <?php endif; ?>
  <form action="/register_action" method="post">

    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="name" class="form-control" id="name" placeholder="Enter name" name="username">
      <?php if($errors->has('username')): ?> <p><?php echo e($errors -> first('username')); ?></p> <?php endif; ?>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      <?php if($errors->has('email')): ?> <p><?php echo e($errors -> first('email')); ?></p> <?php endif; ?>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
      <?php if($errors->has('pwd')): ?> <p><?php echo e($errors -> first('pwd')); ?></p> <?php endif; ?>
    </div>

     <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Confirm password" name="cpwd">
      <?php if($errors->has('cpwd')): ?> <p><?php echo e($errors -> first('cpwd')); ?></p> <?php endif; ?>
    </div>
    <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>