	<?php $__env->startSection('title', 'Teams'); ?></title>
	<?php $__env->startSection('content'); ?>
		<div class="row">
			<form class="navbar-form" role="search" method="GET" action="<?php echo e(url("Football/teams1")); ?>">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by maximum goals </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

    <form class="navbar-form" role="search" method="GET" action="<?php echo e(url("Football/teams2")); ?>">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by maximum matches played </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

    <form class="navbar-form" role="search" method="GET" action="<?php echo e(url("Football/teams3")); ?>">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by minimum minutes played </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

			<div class="col-md-12">
			<h3 align="center">Teams Data</h3>
			<table class="table table-bordered">
				

				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>Minutes_Played</th>
					<th>Goals_Scored</th>
					<th>Matches_Played</th>
					<th>Yellow_Cards</th>
				</tr>
				<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($row['id']); ?></td>
					<td><?php echo e($row['Player']); ?></td>
					<td><?php echo e($row['Country']); ?></td>
					<td><?php echo e($row['Minutes_Played']); ?></td>
					<td><?php echo e($row['Goals_Scored']); ?></td>
					<td><?php echo e($row['Matches_Played']); ?></td>
					<td><?php echo e($row['Yellow_Cards']); ?></td>

				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</table>
		
		</div>
				
		</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('newhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>