@extends('newhome')
	@section('title', 'Match2')</title>
	@section('content')
	<form class="navbar-form" role="search" method="GET" action="{{url("/match")}}">
        <div class="input-group">
            <label>   Search by Team1 Name
            <div class="input-group-btn" >
                <input type="text" class="form-control" placeholder="Search" name="title">
            
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button></label>
            </div>
            <label>   Search by Winning Team Name
            <div class="input-group-btn" >
                <input type="text" class="form-control" placeholder="Search" name="win">
            
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button></label>
            </div>
        </div>
    </form>

<table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>DATE</th>
                    <th>TEAM1</th>
                    <th>TEAM1 SCORE</th>
                    <th>TEAM2</th>
                    <th>TEAM2 SCORE</th>
                    <th>WINS</th>
                    <th>STADIUM</th>
                </tr>
        
@if(count($a)>0)
@foreach($a as $matches)
<tr>
<td>{{ $matches->id }}</td>
<td>{{ $matches->date }}</td>
<td>{{ $matches->team1 }}</td>
<td>{{ $matches->team1_goal }}</td>
<td>{{ $matches->team2 }}</td>
<td>{{ $matches->team2_goal }}</td>
<td>{{ $matches->win_team }}</td>
<td>{{ $matches->stadium }}</td>
</tr>
@endforeach
</table>
@endif


        @endsection