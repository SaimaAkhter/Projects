@extends('newhome')
	@section('title', 'Groups')</title>
	@section('content')
	<form class="navbar-form" role="search" method="GET" action="{{url("/groups1")}}">
        <div class="input-group">
            <label>   Search by Group Name
            <div class="input-group-btn" >
                <input type="text" class="form-control" placeholder="Search" name="title">
            
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button></label>
            </div>
        </div>
    </form>

<table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>GROUP NAME</th>
                    <th>COUNTRY</th>
                    
                </tr>
        
@if(count($a)>0)
@foreach($a as $groups)
<tr>
<td>{{ $groups->id }}</td>
<td>{{ $groups->Group_Name }}</td>
<td>{{ $groups->Country }}</td>

</tr>
@endforeach
</table>
@endif


        @endsection