@extends('newhome')
	@section('title', 'Match')</title>
	@section('content')
	
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">MATCH DETAILS</h3>
			
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>DATE</th>
					<th>TEAM1</th>
					<th>TEAM1 SCORE</th>
					<th>TEAM2</th>
					<th>TEAM2 SCORE</th>
					<th>WINS</th>
					<th>STADIUM</th>
				</tr>
        
@if(count($a)>0)
@foreach($a as $matches)
<tr>
<td>{{ $matches->id }}</td>
<td>{{ $matches->date }}</td>
<td>{{ $matches->team1 }}</td>
<td>{{ $matches->team1_goal }}</td>
<td>{{ $matches->team2 }}</td>
<td>{{ $matches->team2_goal }}</td>
<td>{{ $matches->win_team }}</td>
<td>{{ $matches->stadium }}</td>
</tr>
@endforeach
</table>
@endif
</div>
</div>


	@endsection