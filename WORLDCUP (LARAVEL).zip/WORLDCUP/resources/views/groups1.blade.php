@extends('newhome')
	@section('title', 'Groups1')</title>
	@section('content')

<table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>GROUP NAME</th>
                    <th>COUNTRY</th>
                    
                </tr>
        
@if(count($a)>0)
@foreach($a as $groups)
<tr>
<td>{{ $groups->id }}</td>
<td>{{ $groups->Group_Name }}</td>
<td>{{ $groups->Country }}</td>

</tr>
@endforeach
</table>
@endif


        @endsection