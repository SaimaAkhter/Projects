@extends('newhome')
	@section('title', 'news')</title>
    <style type="text/css">
    	/*.container{
    		
    		height: 200px;
    	}*/
    	img{
    		width:100%;
            height: 200px;
        }
    </style>
	@section('content')
	<div class="container">
		<div class="row">

			<div class="col-sm-3">
				<div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 0" >
        <div class="container"style="color:green">
        	<img class="img" src="images\news.jpg" > 
        	<p style="color:green">Deschamps to attend FIFA Football Conference in London</p>
            <a href="/news1" class="btn-btn-primary"><label>Show Details</label></a>

            <br>
            <br>
            <br>
            <div class="container" style="color:green;">

                <form>
                    <div class="form-group row">
                        
                        <span class="switchButton" id="switchButton"></span>           
                    
                   </div>
                </form>
            </div>

        </div>
    </div>

			</div>
			<div class="col-sm-3" >
				<div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 0">
        <div class="container"style="color:green;">
        	 <img class="img" src="images\new.jpg">
            <p style="color:green;">Bento appointed Korea Republic coach</p>
            <a href="/news2" class="btn-btn-primary"><label>Show Details</label></a>
            <p style="color:green;"></p>

            <br>
            <br>
            <br>
            <div class="container" style="color:green;">

                <form>
                    <div class="form-group row">
                        
                        <span class="switchButton" id="switchButton"></span>           
                    
                   </div>
                </form>
            </div>

        </div>
    </div>

			</div>
			<div class="col-sm-3" >
				<div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 0">
        <div class="container"style="color:green;">
        	<img class="img" src="images\news3.jpg">
            <p style="color:green;">Russia still gripped by Dzyuba-mania</p>
            <a href="/news3" class="btn-btn-primary"><label>Show Details</label></a>

            <br>
            <br>
            <br>
            <div class="container" style="color:green;">

                <form>
                    <div class="form-group row">
                        
                        <span class="switchButton" id="switchButton"></span>           
                    
                   </div>
                </form>
            </div>

        </div>
    </div>

			</div>
			<div class="col-sm-3" style="padding: 0">
				<div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 0">
        <div class="container"style="color:green;">
        	<img class="img" src="images\news4.jpg">
            <p style="color:green;">A golden year for French football</p>
            <a href="/news4" class="btn-btn-primary"><label>Show Details</label></a>

            <br>
            <br>
            <br>
            <div class="container" style="color:green;">

                <form>
                    <div class="form-group row">
                        
                        <span class="switchButton" id="switchButton"></span>           
                    
                   </div>
                </form>
            </div>

        </div>
    </div>

			</div>
		</div>
	</div>
	@endsection