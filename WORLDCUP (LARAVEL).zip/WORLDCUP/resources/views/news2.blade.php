@extends('newhome')
	@section('title', 'news')</title>
    <style type="text/css">
    	/*.container{
    		
    		height: 200px;
    	}*/
    	img{
    		width:500px;
    	height: 2px;
    	
    }
    </style>
	@section('content')
    <div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 100px;" >
	<p>
    <span>Korea Republic have named former Portugal boss Paulo Bento as their new coach, taking the reins from Shin Taeyong who led them at the 2018 FIFA World Cup Russia™.

The 49-year-old's appointment was announced at a press conference on Friday, with Kim Pangon, chief of national team supervisory committee, outlining the former Sporting CP coach as the man to take them forward on the road to Qatar 2022.

Bento has prior experience of the World Cup, having guided his country between 2010 and 2014, and leading Portugal at Brazil 2014. Their group stage exit ultimately fell short of their previous major tournament experience at UEFA EURO 2012, where he took them to the quarter-final.

</span></p>
</div>

	@endsection