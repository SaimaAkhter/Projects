@extends('newhome')
	@section('title', 'READ')</title>
	<style type="text/css">
		.right{
front-weight:bold;
color:#FFFFFF;
background-color:#98bf21;
width:120px;
text-align:center;
padding:4px;
text-transform:uppercase;
text-decoration:none;
}
	</style>

	@section('content')
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">AWARDS DETAILS</h3>
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>AWARD NAME</th>
					<th>Age </th>
					<th>International Goals</th>
				</tr>
				<tr>
					<td>{{$awards['id']}}</td>
					<td>{{$awards['Player']}}</td>
					<td>{{$awards['Country']}}</td>
					<td>{{$awards['Award_Name']}}</td>
					<td>{{$awards['Age']}}</td>
					<td>{{$awards['Int_Goals']}}</td>
					</tr>
			</table>
		
		</div>
				
		</div>

	@endsection