@extends('newhome')
	@section('title', 'Display')</title>
	<style type="text/css">
		.right{
front-weight:bold;
color:#FFFFFF;
background-color:#98bf21;
width:120px;
text-align:center;
padding:4px;
text-transform:uppercase;
text-decoration:none;
}
	</style>

	@section('content')
	<div class="row">
			<div class="col-md-12">
			<h3 align="center">AWARDS DETAILS</h3>
			@if($message = Session::get('success'))
			<div class="alert alert-success">
					<p>{{ $message }}</p>
			</div>
			@endif
			<div class="right" align="right">
				<a href="/Award/insert" class="btn-btn-primary">ADD</a>
			</div>
			<table class="table table-bordered">
				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>AWARD NAME</th>
					<th>Age </th>
					<th>International Goals</th>
					<th>Action</th>
				</tr>
				@foreach($awards as $row)
				<tr>
					<td>{{$row['id']}}</td>
					<td>{{$row['Player']}}</td>
					<td>{{$row['Country']}}</td>
					<td>{{$row['Award_Name']}}</td>
					<td>{{$row['Age']}}</td>
					<td>{{$row['Int_Goals']}}</td>
					<td>
						<a href="/Award/read/{{$row['id']}}" class="btn-btn-primary">READ</a>
						<a href="/Award/update/{{$row['id']}}" class="btn-btn-primary">UPDATE</a>
						<a href="/Award/delete/{{$row['id']}}" class="btn-btn-primary">DELETE</a>
					</td>

				</tr>
				@endforeach
			</table>
		
		</div>
				
		</div>

	@endsection