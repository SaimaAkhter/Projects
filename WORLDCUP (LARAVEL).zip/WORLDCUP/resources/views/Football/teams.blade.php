@extends('newhome')
	@section('title', 'Teams')</title>
	@section('content')
		<div class="row">
			<form class="navbar-form" role="search" method="GET" action="{{url("Football/teams1")}}">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by maximum goals </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

    <form class="navbar-form" role="search" method="GET" action="{{url("Football/teams2")}}">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by maximum matches played </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

    <form class="navbar-form" role="search" method="GET" action="{{url("Football/teams3")}}">
        <div class="input-group">
            <label style="padding: 10px 20px">   Search by minimum minutes played </label>
            <div class="input-group-btn" >
             <button class="btn btn-default" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
            </div>
    </div>
    </form>

			<div class="col-md-12">
			<h3 align="center">Teams Data</h3>
			<table class="table table-bordered">
				

				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>Minutes_Played</th>
					<th>Goals_Scored</th>
					<th>Matches_Played</th>
					<th>Yellow_Cards</th>
				</tr>
				@foreach($teams as $row)
				<tr>
					<td>{{$row['id']}}</td>
					<td>{{$row['Player']}}</td>
					<td>{{$row['Country']}}</td>
					<td>{{$row['Minutes_Played']}}</td>
					<td>{{$row['Goals_Scored']}}</td>
					<td>{{$row['Matches_Played']}}</td>
					<td>{{$row['Yellow_Cards']}}</td>

				</tr>
				@endforeach
			</table>
		
		</div>
				
		</div>
	@endsection