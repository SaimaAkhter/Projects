@extends('newhome')
	@section('title', 'Teams1')</title>
	@section('content')
		<div class="row">
			<div class="col-md-12">
			<h3 align="center">Teams Data</h3>
			<table class="table table-bordered">
				

				<tr>
					<th>ID</th>
					<th>Player</th>
					<th>Country</th>
					<th>Minutes_Played</th>
					<th>Goals_Scored</th>
					<th>Matches_Played</th>
					<th>Yellow_Cards</th>
				</tr>
				@foreach($a as $row)
				<tr>
					<td>{{$row['id']}}</td>
					<td>{{$row['Player']}}</td>
					<td>{{$row['Country']}}</td>
					<td>{{$row['Minutes_Played']}}</td>
					<td>{{$row['Goals_Scored']}}</td>
					<td>{{$row['Matches_Played']}}</td>
					<td>{{$row['Yellow_Cards']}}</td>

				</tr>
				@endforeach
			</table>
		
		</div>
				
		</div>
	@endsection