@extends('newhome')
	@section('title', 'news')</title>
    <style type="text/css">
    	/*.container{
    		
    		height: 200px;
    	}*/
    	img{
    		width:500px;
    	height: 2px;
    	
    }
    </style>
	@section('content')
    <div class="jumbotron jumbotron-fluid ag"style="color:green;padding: 100px;" >
	<p>
    <span>FIFA World Cup™-winning coach Didier Deschamps will share his view on France’s path to glory at the FIFA Football Conference in London on 23 September 2018.

Besides Deschamps, all other FIFA World Cup semi-finalist coaches – Croatia’s Zlatko Dalic, Belgium’s Roberto Martinez and England’s Gareth Southgate – as well as Russia’s Stanislav Cherchesov and 2014 FIFA World Cup champion manager Joachim Low, among many others, have registered for the conference. More than 140 coaches have already signed up and the list is set to increase.

“I obviously responded favourably to FIFA’s invitation as soon as it was received," said Deschamps. "This kind of meeting is always a privileged moment to see my colleagues from other nations and share our experiences. I have always felt the utmost respect for all of them and our title of world champions will not change that point of view."

The head coaches and technical directors of all 211 member associations, as well as the technical experts of all six confederations, have been invited by FIFA to the conference, which aims to analyse the FIFA World Cup from a technical and tactical point of view, identify trends and compare the main findings with previous editions of the FIFA World Cup based on the report by FIFA’s Technical Study Group (TSG) and assess the impact of VAR on the game</span></p>
</div>

	@endsection