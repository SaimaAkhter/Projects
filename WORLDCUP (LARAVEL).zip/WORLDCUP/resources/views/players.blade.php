@extends('newhome')
	@section('title', 'Player')</title>
	@section('content')


	<table class="table table-bordered">
				<tr>
					<th>Player</th>
					<th>Age</th>
					<th>Height</th>
					<th>International Goals</th>
					<th>International Caps</th>
					<th>Minutes Played</th>
					<th>Goals Scored</th>
					<th>Matches Played</th>
					<th>Yellow Cards</th>
				</tr>
        
@if(count($a)>0)
@foreach($a as $player)
<tr>
<td>{{ $player->Player }}</td>
<td>{{ $player->Age }}</td>
<td>{{ $player->Height }}</td>
<td>{{ $player->Int_goals }}</td>
<td>{{ $player->Int_caps }}</td>
<td>{{ $player->Minutes_Played }}</td>
<td>{{ $player->Goals_Scored }}</td>
<td>{{ $player->Matches_Played }}</td>
<td>{{ $player->Yellow_Cards }}</td>


</tr>
@endforeach
</table>
@endif

@endsection
